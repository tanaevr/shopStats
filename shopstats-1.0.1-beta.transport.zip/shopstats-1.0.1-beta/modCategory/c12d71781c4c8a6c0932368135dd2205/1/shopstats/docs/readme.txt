--------------------
shopStats
--------------------
Author: Tanaev Roman <tanaevr@gmail.com>
--------------------

A basic Extra for MODx Revolution.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/tanaevr/shopStats/issues
