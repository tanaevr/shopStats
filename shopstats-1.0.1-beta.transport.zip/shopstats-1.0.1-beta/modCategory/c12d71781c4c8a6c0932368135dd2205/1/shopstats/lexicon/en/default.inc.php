<?php
include_once 'setting.inc.php';

$_lang['shopstats'] = 'shopStats';
$_lang['shopstats.total_orders'] = 'Totaal orders';
$_lang['shopstats.money_turnover'] = 'Money turnover';
$_lang['shopstats.currency'] = '€';
$_lang['shopstats.customers'] = 'Customers';
$_lang['shopstats.orders'] = 'Orders';
$_lang['shopstats.finance'] = 'Finance';