<?php

$_lang['area_shopstats_main'] = 'Main';

$_lang['setting_shopstats_namespace'] = 'Package name online store';
$_lang['setting_shopstats_namespace_desc'] = 'Supported only `minishop2` and` shopkeeper2`.';
