<?php
include_once 'setting.inc.php';

$_lang['shopstats'] = 'shopStats';
$_lang['shopstats.total_orders'] = 'Totaal bestellingen';
$_lang['shopstats.money_turnover'] = 'Geldomzet';
$_lang['shopstats.currency'] = '€';
$_lang['shopstats.customers'] = 'Gebruikers';
$_lang['shopstats.orders'] = 'Bestellingen';
$_lang['shopstats.finance'] = 'Financiën';