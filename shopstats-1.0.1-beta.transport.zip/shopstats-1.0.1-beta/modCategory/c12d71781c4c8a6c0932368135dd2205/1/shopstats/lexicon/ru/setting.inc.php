<?php

$_lang['area_shopstats_main'] = 'Основные';

$_lang['setting_shopstats_namespace'] = 'Название пакета интернет-магазина';
$_lang['setting_shopstats_namespace_desc'] = 'Поддерживается только `minishop2` и `shopkeeper2`.';

